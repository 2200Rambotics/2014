/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.AnalogChannel;


public class ArmPot
{
    public AnalogChannel armFSensor;
    public AnalogChannel armBSensor;
    public Talon armFMotor;
    public Talon armFRoller;
    public Talon armBMotor;
    public Talon armBRoller;
    public boolean isHold;
    public boolean isB;
    public boolean isF;
    public boolean isShoot;
    public boolean isPass;
    public int holdCount;
    public int bCount;
    public int fCount;
    public int shootCount;
    public int passCount;
    private boolean rollFlag;
    private boolean fFlag;
    private boolean bFlag;
    private ShooterLogicPot shooterlogic;
    private double wantHoldF;
    private double wantShootF;
    private double wantDownF;
    private double wantHoldB;
    private double wantShootB;
    private double wantDownB;
    private double offset;
    ArmPot(Talon armFMotor, Talon armFRoller, Talon armBMotor, Talon armBRoller, ShooterLogicPot shooterLogicPot)
    {
        this.armFMotor = armFMotor;
        this.armFRoller = armFRoller;
        this.armBMotor = armBMotor;
        this.armBRoller = armBRoller;
        this.shooterlogic = shooterLogicPot;
//        armFSensor = new AnalogChannel(3);
//        armBSensor = new AnalogChannel(4);
        isHold = rollFlag = isB = isF = isShoot = fFlag = bFlag = isPass = false;
        holdCount = bCount = fCount = shootCount = passCount = 0;
        
    }
    
    
    
    //arms hold ball
    public void armHold()
    {
        isHold = true;
        isF = isB = isShoot = isPass = false;
    }
    //front arm spin and down
    public void armF()
    {
        isB = isShoot = isPass = isHold = false;
        isF = true;
    }
    //back arm spin and down
    public void armB()
    {
        isF = isShoot = isPass = isHold = false;
        isB = true;
    }
    //arms drop, both spin, only call when shoot
    public void armShoot()
    {
        isF = isB = isPass = isHold = false;
        isShoot = true;
    }
    //front arm drops while spinning rollers out to pass
    public void armPass()
    {
        isF = isB = isShoot = isHold = false;
        isPass = true;
    }
    
    public void run() 
    {
        wantHoldF = SmartDashboard.getNumber("Front Hold: ", 3);
        wantShootF = SmartDashboard.getNumber("Front Shoot: ", 2);
        wantDownF = SmartDashboard.getNumber("Front Down: ", 1);
        wantHoldB = SmartDashboard.getNumber("Back Hold: ", 3);
        wantShootB = SmartDashboard.getNumber("Back Shoot: ", 2);
        wantDownB = SmartDashboard.getNumber("Back Down: ", 1);
        offset = SmartDashboard.getNumber("Offset: ", 0.5);
        
        shooterlogic.checkSwitchs();
        SmartDashboard.putNumber("armF", armFMotor.get());
        SmartDashboard.putNumber("armB", armBMotor.get());
        SmartDashboard.putBoolean("hold:", isHold);
        SmartDashboard.putBoolean("isF", isF);
        SmartDashboard.putBoolean("isB", isB);
        SmartDashboard.putBoolean("fFlag", fFlag);
        SmartDashboard.putBoolean("bFlag", bFlag);
        SmartDashboard.putBoolean("isShoot", isShoot);
        if (isHold) 
        {
            //back arm stay hold loop
            if((wantHoldB - offset) < shooterlogic.BVolt)
            {
                armBMotor.set(1);
                armBRoller.set(1);
            }
            else if ((wantHoldB + offset) > shooterlogic.BVolt)
            {
                armBMotor.set(-1);
            } 
            else 
            {
                armBRoller.set(0);
                armBMotor.set(0);
            }
            
            //front arm stay hold loop
            if((wantHoldF - offset) < shooterlogic.FVolt)
            {
                armFRoller.set(1);
                armFMotor.set(1);
            }
            else if ((wantHoldF + offset) > shooterlogic.FVolt)
            {
                armFMotor.set(-1);
            }
            else
            {
                armFRoller.set(0);
                armFMotor.set(0);
            }
            
            
        } 
        else 
        {
            if (isF) 
            {
                armFRoller.set(1);
                //front arm down
                if((wantDownF - offset) < shooterlogic.FVolt)
                {
                    armFMotor.set(1);
                    
                }
                else if ((wantDownF + offset)> shooterlogic.FVolt)
                {
                    armFMotor.set(-1);
                }
                else
                {
                    armFMotor.set(0);
                }
                
                //back arm up
                if((wantHoldB - offset)< shooterlogic.BVolt)
                {
                    armBMotor.set(1);
                }
                else if((wantHoldB + offset) > shooterlogic.BVolt)
                {
                    armBMotor.set(-1);
                }
                else
                {
                    armBMotor.set(0);
                }
            }
            if (isB) 
            {
                armBRoller.set(1);
                //front arm down
                if((wantHoldF - offset) < shooterlogic.FVolt)
                {
                    armFMotor.set(1);
                }
                else if ((wantHoldF + offset)> shooterlogic.FVolt)
                {
                    armFMotor.set(-1);
                }
                else
                {
                    armFMotor.set(0);
                }
                
                //back arm up
                if((wantDownB - offset)< shooterlogic.BVolt)
                {
                    armBMotor.set(1);
                }
                else if((wantDownB + offset) > shooterlogic.BVolt)
                {
                    armBMotor.set(-1);
                }
                else
                {
                    armBMotor.set(0);
                }
            }
            if (isShoot) 
            {
                //front arm down
                if((wantDownF - offset) < shooterlogic.FVolt)
                {
                    armFMotor.set(1);
                }
                else if ((wantDownF + offset)> shooterlogic.FVolt)
                {
                    armFMotor.set(-1);
                }
                else
                {
                    armFMotor.set(0);
                }
                
                //back arm up
                if((wantDownB - offset)< shooterlogic.BVolt)
                {
                    armBMotor.set(1);
                }
                else if((wantDownB + offset) > shooterlogic.BVolt)
                {
                    armBMotor.set(-1);
                }
                else
                {
                    armBMotor.set(0);
                }
            }
            if (isPass) 
            {
                
            }
        }
    }
    
}
