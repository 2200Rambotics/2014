/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.SimpleRobot;
/**
 *
 * @author Rambotics
 */
public class autoThree {
    RobotDrive gingerDrive;
    ShooterLogic shooterlogic;
    DigitalInput infra =  new DigitalInput(6);
    private boolean isBall;
    private double autoStartTime;
    
    autoThree(RobotDrive robodrive, ShooterLogic shooterlogic) {
        this.gingerDrive = robodrive;
        this.shooterlogic = shooterlogic;
        isBall = true;
    }
    public void checkInfra()
    {
        isBall = infra.get();
        SmartDashboard.putBoolean("isBall", isBall);
    }
    
    public void run() {
        autoStartTime = Timer.getFPGATimestamp();
        gingerDrive.setSafetyEnabled(false);
        shooterlogic.isShootMode = true;
        shooterlogic.arms.armShoot();
        shooterlogic.isDoneShooting = false;
        System.out.println("after...");
        while ( shooterlogic.isDoneShooting == false)
        {
            shooterlogic.run();
            System.out.println("ran shooter run");

        }
        shooterlogic.isWinchMode = true;
        while (!shooterlogic.shootArmDown.get())
        {
            shooterlogic.winchArm.set(-1);
        }
        shooterlogic.winchArm.set(0);
        checkInfra();
        while(isBall && (10 -(Timer.getFPGATimestamp() - autoStartTime)) > 2)
        {
            checkInfra();
            shooterlogic.arms.armBRoller.set(1);
        }
//        shooterlogic.arms.armBRoller.set(1);
//        Timer.delay(1.2);
        shooterlogic.isShootMode = false;
        shooterlogic.arms.armHold();
        while (shooterlogic.arms.isHold && !isBall)
        {
            shooterlogic.run();
        }
        Timer.delay(0.75);
        shooterlogic.isShootMode = true;
        shooterlogic.arms.armShoot();
        shooterlogic.isDoneShooting = false;
        System.out.println("after...");
        while ( shooterlogic.isDoneShooting == false && !isBall)
        {
            shooterlogic.run();
            System.out.println("ran shooter run");

        }
        shooterlogic.arms.armHold();
        while (shooterlogic.arms.isHold) {
            shooterlogic.run();
            
        }
        gingerDrive.tankDrive(-0.5, 0.5);
        Timer.delay(0.75);
        System.out.println("Drive code");
        gingerDrive.tankDrive(1.0, 1.0);
        Timer.delay(1);
        gingerDrive.drive(0,0);
    }
    
}
