/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.DigitalOutput;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.AnalogChannel;

import edu.wpi.first.wpilibj.templates.Arms;

/**
 *
 * @author Rambotics
 */
public class ShooterLogic 
{
    public boolean isOverTravel;
    public boolean isShootArmDown;
    public boolean isWinchCam;
    public boolean isBallInShooter;
    public boolean isDisarm;
    private int joystickButton;
    private Joystick joystick;
    public boolean isOverride;
    private boolean isShootMode;
    private boolean isWinchMode;
    private boolean isWinchLockMoving;
    private Relay winchLock;
    private Talon winchArm;
    private int winchCount;
    private boolean winchWaitForTrue;
    public double armFWanted;
    public double armBWanted;
    public double armFActual;
    public double armBActual;
    DigitalInput infraIn = new DigitalInput(10);
    DigitalOutput infraOut = new DigitalOutput(11);
    DigitalInput shootArmOverTravel = new DigitalInput(7);
    DigitalInput shootArmDown = new DigitalInput(8);
    DigitalInput winchCamSwitch = new DigitalInput(9);
    AnalogChannel armFFlex = new AnalogChannel(3);
    AnalogChannel armBFlex = new AnalogChannel(4);
    Arms arms;
    public boolean joy3;
    public boolean joy2;
    
    ShooterLogic(int joystickNumber, int joystickbuttonNumber, 
            Relay winchLock, Talon winchArm)
    {
        this.winchArm = winchArm;
        this.winchLock = winchLock;
        winchCount = 0;
        
        
        joystick = new Joystick(joystickNumber);
        joystickButton = joystickbuttonNumber;
        isOverTravel = winchWaitForTrue = isBallInShooter = isShootArmDown = isWinchCam = isWinchLockMoving =
                isDisarm = isOverride = isShootMode = isWinchMode = joy3 = joy2 = false;
        isBallInShooter = true;
        arms = new Arms();
        this.checkSwitchs();
        
    }
    public boolean isArmHold()
    {
        //TODO: make
        return true;
    }
    public void checkSwitchs()
    {
        
        //Arm Over Travel Sensor     
        if(shootArmOverTravel.get() == false)
        {
            isOverTravel = true;
        }
        if(isOverTravel == true)
        {
            SmartDashboard.putString("", "ARM NOT OKAY!");
        }
        
        //Arm down switch, dig 8
        if(shootArmDown.get() == true)
        {
            isShootArmDown = true;
            SmartDashboard.putString("Shooter Arm Status: ", "Down/Charged");
        }
        else
        {
            SmartDashboard.putString("Shooter Arm Status: ", "Up/Launched");
            isShootArmDown = false;
        }
        
        //winch cam switch
        if(winchCamSwitch.get() == true)
        {
            isWinchCam = true;
            SmartDashboard.putString("Winch Cam Status: ", "Locked");
        }
        else
        {
            isWinchCam = false;
            SmartDashboard.putString("Winch Cam Status: ", "Unlocked");
        }
        
        //TODO: infrared
        
    }
    public boolean isArmShoot()
    {
        //TODO: make
        return true;
    }
    public void run()
    {
        
        checkSwitchs();
        arms.run();
        
        if (joystick.getRawButton(3) && !joy3)
        {
            arms.armF();
            joy3 = true;
        } 
        else if (joystick.getRawButton(2) && !joy2)
        {
            arms.armB();
            joy2 = true;
        } 
        else if ((joy2 || joy3) && !joystick.getRawButton(3) && !joystick.getRawButton(2))
        {
            arms.armHold();
            joy3 = joy2 = false;
        }
        
        boolean buttonState = joystick.getRawButton(joystickButton);
        isOverride = joystick.getRawButton(9);
        isWinchMode = joystick.getRawButton(4);
        if (buttonState && isWinchCam && isBallInShooter && isArmHold() &&
                !isShootMode && !isWinchLockMoving && !isWinchMode && !isDisarm)
        {
            isShootMode = true;
            arms.armShoot();
        }
        else if(isOverride && buttonState)
        {
            isShootMode = true;
        }
        if(isShootMode)
        {
            if(!arms.isShoot)
            {
                winchLock.set(Relay.Value.kForward);
                isWinchLockMoving = true;
                isShootMode = false;
            }

        }
        if (isWinchLockMoving)
            {
                if(!isWinchCam)
                {
                    winchWaitForTrue = true;
                }
                if(isWinchCam && winchWaitForTrue)
                {
                    winchLock.set(Relay.Value.kOff);
                    isWinchLockMoving = false;
                    winchWaitForTrue = false;
                    arms.armHold();
                    
                }
            }
                
                    
        if(isWinchMode)
        {
            if(isShootArmDown)
            {
                winchArm.set(0);
                isWinchMode = false;
            }
            else 
            {
                winchArm.set(-1);
            }
            
        } else 
        {
            winchArm.set(0);
        }
        
    }
    
    
    
}
