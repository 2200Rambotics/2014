/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.DigitalOutput;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.AnalogPotentiometer;


/**
 *
 * @author Rambotics
 */
public class ShooterLogic 
{
    public boolean isOverTravel;
    public boolean isShootArmDown;
    public boolean isWinchCam;
    public boolean isBallInShooter;
    public boolean isDisarm;
    private int joystickButton;
    private Joystick joystick;
    public boolean isOverride;
    private boolean isShootMode;
    private boolean isWinchMode;
    private boolean isWinchLockMoving;
    private Talon arm1;
    private Talon arm2;
    private Relay winchLock;
    private Talon winchArm;
    private int winchCount;
    DigitalInput infraIn = new DigitalInput(10);
    DigitalOutput infraOut = new DigitalOutput(11);
    DigitalInput shootArmOverTravel = new DigitalInput(7);
    DigitalInput shootArmDown = new DigitalInput(8);
    DigitalInput winchCamSwitch = new DigitalInput(9);
    private boolean winchWaitForTrue;
    AnalogPotentiometer potenL = new AnalogPotentiometer(3);
    AnalogPotentiometer potenR = new AnalogPotentiometer(4);
    double potenLRead;
    double potenRRead;
    double potenLInput;
    double potenRInput;
    
    
    ShooterLogic(int joystickNumber, int joystickbuttonNumber, 
            Talon arm1 ,Talon arm2, Relay winchLock, Talon winchArm)
    {
        this.arm1 = arm1;
        this.arm2 = arm2;
        this.winchArm = winchArm;
        this.winchLock = winchLock;
        winchCount = 0;
        
        
        joystick = new Joystick(joystickNumber);
        joystickButton = joystickbuttonNumber;
        isOverTravel = winchWaitForTrue = isBallInShooter = isShootArmDown = isWinchCam = isWinchLockMoving =
                isDisarm = isOverride = isShootMode = isWinchMode = false;
        this.checkSwitchs();
        SmartDashboard.putNumber("Left Poten Input", potenLInput ); //might need to set a default value
        SmartDashboard.putNumber("Right Poten Input", potenRInput);
        
    }
    public boolean isArmHold()
    {
        //TODO: make
        return false;
    }
    public void checkSwitchs()
    {
        //Poentiometer test code
        potenLRead = potenL.get();
        SmartDashboard.putNumber("Left Potentiometer", potenLRead);
        potenRRead = potenR.get();
        SmartDashboard.putNumber("Right Potentiometer", potenRRead);
        potenLInput = SmartDashboard.getNumber("Left Poten Input");
        potenRInput = SmartDashboard.getNumber("Right Poten Input");
        
        //Arm Over Travel Sensor     
        if(shootArmOverTravel.get() == false)
        {
            isOverTravel = true;
        }
        if(isOverTravel == true)
        {
            SmartDashboard.putString("", "ARM NOT OKAY!");
        }
        
        //Arm down switch, dig 8
        if(shootArmDown.get() == false)
        {
            isShootArmDown = true;
            SmartDashboard.putString("Shooter Arm Status: ", "Down/Charged");
        }
        else
        {
            SmartDashboard.putString("Shooter Arm Status: ", "Up/Launched");
            isShootArmDown = false;
        }
        
        //winch cam switch
        if(winchCamSwitch.get() == false)
        {
            isWinchCam = true;
            SmartDashboard.putString("Winch Cam Status: ", "Locked");
        }
        else
        {
            isWinchCam = true;
            SmartDashboard.putString("WInch Cam Status: ", "Unlocked");
        }
        
        //TODO: infrared
        
    }
    public boolean isArmShoot()
    {
        //TODO: make
        return false;
    }
    public void run()
    {
        
        checkSwitchs();
        boolean buttonState = joystick.getRawButton(joystickButton);
        if (buttonState && isShootArmDown && isWinchCam && isBallInShooter && isArmHold())
        {
            isShootMode = true;
        }
        else if(isOverride && buttonState)
        {
            isShootMode = true;
        }
        if(isShootMode)
        {
            if(isArmShoot())
            {
                arm1.set(0);
                arm2.set(0);
                winchLock.set(Relay.Value.kForward);
                isWinchLockMoving = true;
                isShootMode = false;
            }
            else
            {
                arm1.set(1);
                arm2.set(1);
            }
            
            // Once upon a time in a code far far away there was this guy typing a bunch of useless things into said code,
            // This is his story...
            // So there wass this guy rite and he was liek some pickles would be liek really gud n stuff so he
            // went to the store and liek bought some pickles
            // soon enough the neighbourhood bear learned about these pickles and realized he wanted to eat them all
            // The bear tracked and hunted the man for many many years until one day he decided it was time to strike
            // The bear burts through the wall of the mans outdated 1985 camper
            // with swift speed the bear knocked the man to the ground and jacked the pickles
            // But it was all a ruse the pickles were fake.  Suddenly there was a loud ticking
            // the bear realized it was do or die so he gobbled the pickles down jar and everything
            // the bear felt weird almost... powerful
            // The bears stomach began to rumble as he grew to 4 million feet tall
            // but he still exploded and was liek crap and the nuclear winter began.
            // But thats another story...
            // To be continued...
            // Maybe...
            
        }
        if (isWinchLockMoving)
            {
                if(!isWinchCam)
                {
                    winchWaitForTrue = true;
                }
                if(isWinchCam && winchWaitForTrue)
                {
                    winchLock.set(Relay.Value.kOff);
                    isWinchLockMoving = false;
                    winchWaitForTrue = false;
                    if(!isDisarm)
                    {
                        winchArm.set(1);
                        isWinchMode = true;
                    }
                }
            }
                
                    
        if(isWinchMode)
        {
            if(isShootArmDown)
            {
                winchArm.set(0);
                isWinchMode = false;
            }
            
        }
    }
    
    
    
}
