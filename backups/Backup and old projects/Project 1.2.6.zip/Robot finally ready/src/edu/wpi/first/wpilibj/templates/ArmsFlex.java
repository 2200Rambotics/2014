/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.AnalogChannel;



public class ArmsFlex
{
    public AnalogChannel armFSensor;
    public AnalogChannel armBSensor;
    public Talon armFMotor;
    public Talon armFRoller;
    public Talon armBMotor;
    public Talon armBRoller;
    public boolean isHold;
    public boolean isB;
    public boolean isF;
    public boolean isShoot;
    public int holdCount;
    public int bCount;
    public int fCount;
    public int shootCount;
    public double FVolt;
    public double BVolt;
    
    ArmsFlex()
    {
        armFMotor = new Talon(3);
        armFRoller = new Talon(5);
        armBMotor = new Talon(4);
        armBRoller = new Talon(6);
        armFSensor = new AnalogChannel(3);
        armBSensor = new AnalogChannel(4);
        isHold = isB = isF = isShoot = false;
        holdCount = bCount =  fCount = shootCount = 0;
        FVolt = BVolt = 0;
        
        
    }
    //arms hold ball
    public void armHold()
    {
        isHold = true;
    }
    //front arm spin and down
    public void armF()
    {
        isF = true;
    }
    //back arm spin and down
    public void armB()
    {
        isB = true;
    }
    //arms drop, both spin, only call when shoot
    public void armShoot()
    {
        isShoot = true;
    }
    
    public void run() 
    {
        SmartDashboard.putNumber("armF", armFMotor.get());
        SmartDashboard.putNumber("armB", armBMotor.get());
        SmartDashboard.putBoolean("hold:", isHold);
        SmartDashboard.putBoolean("isF", isF);
        SmartDashboard.putBoolean("isB", isB);
        SmartDashboard.putBoolean("isShoot", isShoot);
        FVolt = armFSensor.getVoltage();
        BVolt = armBSensor.getVoltage();
        SmartDashboard.putNumber("FVolt: ", FVolt);
        SmartDashboard.putNumber("BVolt: ", BVolt);
        
        
        
        
    }
    
    
    
        
    
}
