/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.AnalogChannel;


public class Arms 
{
    public AnalogChannel armFSensor;
    public AnalogChannel armBSensor;
    public Talon armFMotor;
    public Talon armFRoller;
    public Talon armBMotor;
    public Talon armBRoller;
    public boolean isHold;
    public boolean isB;
    public boolean isF;
    public boolean isShoot;
    public int holdCount;
    public int bCount;
    public int fCount;
    public int shootCount;
    private boolean rollFlag;
    
    Arms()
    {
        armFMotor = new Talon(3);
        armFRoller = new Talon(5);
        armBMotor = new Talon(4);
        armBRoller = new Talon(6);
//        armFSensor = new AnalogChannel(3);
//        armBSensor = new AnalogChannel(4);
        isHold = rollFlag = isB = isF = isShoot = false;
        holdCount = bCount = fCount = shootCount = 0;
        
    }
    //arms hold ball
    public void armHold()
    {
        isHold = true;
    }
    //front arm spin and down
    public void armF()
    {
        isF = true;
    }
    //back arm spin and down
    public void armB()
    {
        isB = true;
    }
    //arms drop, both spin, only call when shoot
    public void armShoot()
    {
        isShoot = true;
    }
    
    public void run() 
    {
        SmartDashboard.putNumber("armF", armFMotor.get());
        SmartDashboard.putNumber("armB", armBMotor.get());
        SmartDashboard.putBoolean("hold:", isHold);
        SmartDashboard.putBoolean("isF", isF);
        SmartDashboard.putBoolean("isB", isB);
        SmartDashboard.putBoolean("isShoot", isShoot);
        if (isHold) {
            armFMotor.set(0.7);
            armBMotor.set(0.7);
            if(rollFlag)
            {
                armFRoller.set(0.4);
            }
            else if(!rollFlag)
            {
                armBRoller.set(0.4);
            }
            holdCount++;
            fCount = 0;
            isF = false;
            bCount = 0;
            isB = false;
            shootCount = 0;
            isShoot = false;
            if (holdCount >= 70) {
                armFRoller.set(0);
                armBRoller.set(0);
                armFMotor.set(0);
                armBMotor.set(0);
                isHold = false;
                holdCount = 0;
            }
        } else {
            if (isF) {
                armFMotor.set(-0.8);
                armBMotor.set(0.7);
                armFRoller.set(1);
                fCount++;
                if (fCount >= 70) {
                    armFMotor.set(-0.15);
                    armBMotor.set(0);
                    isF = false;
                    fCount = 0;
                    rollFlag = true;
                }
            }
            if (isB) {
                armFMotor.set(0.7);
                armBMotor.set(-0.8);
                armBRoller.set(1);
                bCount++;
                if (bCount >= 70) {
                    armFMotor.set(0);
                    armBMotor.set(-0.15);
                    isB = false;
                    bCount = 0;
                    rollFlag = false;
                }
            }
            if (isShoot) {
                armFMotor.set(-0.8);
                armBMotor.set(-0.8);
//                armFRoller.set(-1);
//                armBRoller.set(-1);
                shootCount++;
                if (shootCount >= 70) {
                    armFMotor.set(-0.15);
                    armBMotor.set(-0.15);
                    isShoot = false;
                    isHold = false;
                    shootCount = 0;
                }
            }
        }
    }
    
}
