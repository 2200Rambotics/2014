/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.DigitalOutput;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.AnalogPotentiometer;


/**
 *
 * @author Rambotics
 */
public class ShooterLogic 
{
    public boolean isOverTravel;
    public boolean isShootArmDown;
    public boolean isWinchCam;
    public boolean isBallInShooter;
    public boolean isDisarm;
    private int joystickButton;
    private Joystick joystick;
    public boolean isOverride;
    private boolean isShootMode;
    private boolean isWinchMode;
    private boolean isWinchLockMoving;
    private Talon arm1;
    private Talon arm2;
    private Relay winchLock;
    private Talon winchArm;
    private int winchCount;
    DigitalInput infraIn = new DigitalInput(10);
    DigitalOutput infraOut = new DigitalOutput(11);
    DigitalInput shootArmOverTravel = new DigitalInput(7);
    DigitalInput shootArmDown = new DigitalInput(8);
    DigitalInput winchCamSwitch = new DigitalInput(9);
    private boolean winchWaitForTrue;
    AnalogPotentiometer potenL = new AnalogPotentiometer(3,100);
    AnalogPotentiometer potenR = new AnalogPotentiometer(4, 100);
    double potenLRead;
    double potenRRead;
    
    
    ShooterLogic(int joystickNumber, int joystickbuttonNumber, 
            Talon arm1 ,Talon arm2, Relay winchLock, Talon winchArm)
    {
        this.arm1 = arm1;
        this.arm2 = arm2;
        this.winchArm = winchArm;
        this.winchLock = winchLock;
        winchCount = 0;
        
        
        joystick = new Joystick(joystickNumber);
        joystickButton = joystickbuttonNumber;
        isOverTravel = winchWaitForTrue = isBallInShooter = isShootArmDown = isWinchCam = isWinchLockMoving =
                isDisarm = isOverride = isShootMode = isWinchMode = false;
        this.checkSwitchs();
        
    }
    public boolean isArmHold()
    {
        //TODO: make
        return false;
    }
    public void checkSwitchs()
    {
        potenLRead = potenL.get();
        SmartDashboard.putNumber("Left Potentiometer", potenLRead);
        potenRRead = potenR.get();
        SmartDashboard.putNumber("Right Potentiometer", potenRRead);
        //Arm Over Travel Sensor     
        if(shootArmOverTravel.get() == false)
        {
            isOverTravel = true;
        }
        if(isOverTravel == true)
        {
            SmartDashboard.putString("", "ARM NOT OKAY!");
        }
        
        //Arm down switch, dig 8
        if(shootArmDown.get() == false)
        {
            isShootArmDown = true;
            SmartDashboard.putString("Shooter Arm Status: ", "Down/Charged");
        }
        else
        {
            SmartDashboard.putString("Shooter Arm Status: ", "Up/Launched");
            isShootArmDown = false;
        }
        
        //winch cam switch
        if(winchCamSwitch.get() == false)
        {
            isWinchCam = true;
            SmartDashboard.putString("Winch Cam Status: ", "Locked");
        }
        else
        {
            isWinchCam = true;
            SmartDashboard.putString("WInch Cam Status: ", "Unlocked");
        }
        
        //TODO: infrared
        
    }
    public boolean isArmShoot()
    {
        //TODO: make
        return false;
    }
    public void run()
    {
        
        checkSwitchs();
        boolean buttonState = joystick.getRawButton(joystickButton);
        if (buttonState && isShootArmDown && isWinchCam && isBallInShooter && isArmHold())
        {
            isShootMode = true;
        }
        else if(isOverride && buttonState)
        {
            isShootMode = true;
        }
        if(isShootMode)
        {
            if(isArmShoot())
            {
                arm1.set(0);
                arm2.set(0);
                winchLock.set(Relay.Value.kForward);
                isWinchLockMoving = true;
                isShootMode = false;
            }
            else
            {
                arm1.set(1);
                arm2.set(1);
            }
            
                
            
        }
        if (isWinchLockMoving)
            {
                if(!isWinchCam)
                {
                    winchWaitForTrue = true;
                }
                if(isWinchCam && winchWaitForTrue)
                {
                    winchLock.set(Relay.Value.kOff);
                    isWinchLockMoving = false;
                    winchWaitForTrue = false;
                    if(!isDisarm)
                    {
                        winchArm.set(1);
                        isWinchMode = true;
                    }
                }
            }
                
                    
        if(isWinchMode)
        {
            if(isShootArmDown)
            {
                winchArm.set(0);
                isWinchMode = false;
            }
            
        }
    }
    
    
    
}
