/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.Talon;


/**
 *
 * @author Rambotics
 */
public class autoTwo
{
    RobotDrive GingerDrive;
    ShooterLogicPot shooterlogic;
    
    
    autoTwo(RobotDrive drive,ShooterLogicPot shooterlogic)
    {
        System.out.println("Made object");
        this.GingerDrive = drive;
        this.shooterlogic = shooterlogic;
        
    }

    public void run(boolean isAuton, boolean isEnabled)
    {
        GingerDrive.setSafetyEnabled(false);
        shooterlogic.isShootMode = true;
        shooterlogic.armpot.armShoot();
        while(!shooterlogic.armpot.BarmIsDown && !shooterlogic.armpot.FarmIsDown)
        {
            shooterlogic.armpot.run();
        }
        shooterlogic.isDoneShooting = false;
        while ( shooterlogic.isDoneShooting == false)
        {
            shooterlogic.run();
            System.out.println("ran shooter run");

        }
        shooterlogic.armpot.armHold();
        while (!shooterlogic.armpot.BarmIsHold && !shooterlogic.armpot.FarmIsHold)
        {
            shooterlogic.run();
        }
        //        while(!timeFlag)
//        {
//            if(Timer.getFPGATimestamp() - startTime < 1)
//            {
//                GingerDrive.drive(0.4, 1);
//                Timer.delay(0.01);
//                System.out.println("in loop");
//                System.out.println(Timer.getFPGATimestamp());
//            }
//            else
//            {
//                timeFlag = true;
//            }
//        }
        GingerDrive.tankDrive(-0.5, 0.5);
        Timer.delay(0.75);
        System.out.println("Drive code");
        GingerDrive.tankDrive(0.5, 0.5);
        Timer.delay(1);
        GingerDrive.drive(0,0);
    }
    
}
