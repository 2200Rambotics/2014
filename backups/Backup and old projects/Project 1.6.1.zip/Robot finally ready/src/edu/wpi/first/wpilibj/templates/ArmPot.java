/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.AnalogChannel;


public class ArmPot
{
    public AnalogChannel armFSensor;
    public AnalogChannel armBSensor;
    public Talon armFMotor;
    public Talon armFRoller;
    public Talon armBMotor;
    public Talon armBRoller;
    public boolean isHold;
    public boolean isB;
    public boolean isF;
    public boolean isShoot;
    public boolean isPass;
    public int holdCount;
    public int bCount;
    public int fCount;
    public int shootCount;
    public int passCount;
    private boolean rollFlag;
    private boolean fFlag;
    private boolean bFlag;
    
    ArmPot(Talon armFMotor, Talon armFRoller, Talon armBMotor, Talon armBRoller)
    {
        this.armFMotor = armFMotor;
        this.armFRoller = armFRoller;
        this.armBMotor = armBMotor;
        this.armBRoller = armBRoller;
//        armFSensor = new AnalogChannel(3);
//        armBSensor = new AnalogChannel(4);
        isHold = rollFlag = isB = isF = isShoot = fFlag = bFlag = isPass = false;
        holdCount = bCount = fCount = shootCount = passCount = 0;
        
    }
    //arms hold ball
    public void armHold()
    {
        isHold = true;
    }
    //front arm spin and down
    public void armF()
    {
        isHold = false;
        isF = true;
    }
    //back arm spin and down
    public void armB()
    {
        isHold = false;
        isB = true;
    }
    //arms drop, both spin, only call when shoot
    public void armShoot()
    {
        isHold = false;
        isShoot = true;
    }
    //front arm drops while spinning rollers out to pass
    public void armPass()
    {
        isHold = false;
        isPass = true;
    }
    
    public void run() 
    {
        SmartDashboard.putNumber("armF", armFMotor.get());
        SmartDashboard.putNumber("armB", armBMotor.get());
        SmartDashboard.putBoolean("hold:", isHold);
        SmartDashboard.putBoolean("isF", isF);
        SmartDashboard.putBoolean("isB", isB);
        SmartDashboard.putBoolean("fFlag", fFlag);
        SmartDashboard.putBoolean("bFlag", bFlag);
        SmartDashboard.putBoolean("isShoot", isShoot);
        if (isHold) 
        {
            
        } 
        else 
        {
            if (isF) 
            {
                
            }
            if (isB) 
            {
                
            }
            if (isShoot) 
            {
                
            }
            if (isPass) 
            {
                
            }
        }
    }
    
}
